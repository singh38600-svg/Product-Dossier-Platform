Optional cover and supporting images.
